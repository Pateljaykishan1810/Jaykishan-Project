﻿34



![A red and white logo with a leaf

Description automatically generated](Aspose.Words.4d1f7fc7-66eb-4c88-89bf-3870057df665.001.png)


**Project - Part #2**

**AWS Data Analytic Platform for The City of Vancouver**

Group 5

Lam Thi Thu Thao (2238441)

Gurleen Kaur Khosa (2308084)

Jaykishan Ashokkumar Patel (2237183)

Ugochukwu Nwosu (2214378)

University Canada West

BUSI 653: Cloud Computing Technologies (HBD-SUMMER24-07)

Mahmood Mortazavi Dehkordi

September 15, 2024



**Contents**

Introduction	4

DAP Design and Implementation (Step 15-17)	4

Step 15: Data Protection	4

Step 16: Data Governance	11

Step 17: Data Monitoring	16

DAP Design and Implementation (Step 15-17)	23

Step 15: Data Protection	23

Step 16: Data Governance	26

Step 17: Data Monitoring	28

DAP Design and Implementation (Steps 15- 17)	30

Step 15: Data Protection	30

Step 16: Data Governance	36

Step 17: Data Monitoring	39

DAP Design and Implementation (Steps 15- 17)	47

Step 15: Data Protection	47

Step 16: Data Governance	48

Step 17: Data Monitoring	49

DAP Architecture Analysis (Teamwork)	50

\1. Operational Excellence	50

\2. Security	51

\3. Reliability	52

\4. Performance Efficiency	54

\5. Cost Optimization	55

\6. Sustainability	56

References	58
**


**AWS Data Analytic Platform for The City of Vancouver**
# <a name="_toc177337076"></a>**Introduction**
The City of Vancouver stands to benefit significantly from utilizing data to enhance decision-making, public services, and resource management. Implementing a Data Analytic Platform (DAP) is crucial as it offers a foundation for integrating, processing, and visualizing large volumes of data from various sources. This platform enables city officials to make informed decisions that enhance the quality of life, service delivery, and city planning.

The DAP's value lies in its ability to convert vast amounts of data into actionable insights. By consolidating data from multiple departments, it provides a comprehensive view of the city’s operations, identifies trends, and helps anticipate future challenges. Additionally, a well-executed DAP promotes transparency and accountability, allowing the city to effectively communicate its achievements and initiatives to the public. The following table outlines the key steps the City of Vancouver must take to successfully implement its DAP, supporting its mission to optimize city operations and improve residents' well-being.

**Dataset 1: Animal Control – Lost and Found Animal (By Lam Thi Thu Thao)**
# <a name="_toc177337077"></a>**DAP Design and Implementation (Step 15-17)**
## <a name="_toc675906450"></a><a name="_toc177337078"></a>**Step 15: Data Protection**
I searched for and practiced KMS (Key Management Service). 

- I created a key with Alias labels: **animalcontrol-lostandfoundanimal-key-lamthithuthao**
- My domain: Animal Control
- Information description admission or procedure: Lost and Found Animal 
- Function of this source: Key

First, I defined the key administrative permissions required by providing actions that need to be controlled, meaning who can delete, destroy, or change the conditions for the key. Since no role was specified, I chose LabRole from my previous practice as the responsible role for maintaining the key. With LabRole assigned, any person bearing this role would be able to carry out administrative tasks like key deletion, destruction, or modification of its conditions. This allows effective management whereby all persons bearing the LabRole can manage the key with much ease.

**Figure 1.1**

*Lost and Found Animal - Define key administrative permissions*

During this below step, I grant permissions related to key usage. Mainly we identify who possesses the key and can use it for encrypting rather than decrypting. we can assign a LabRole and require "anyone in this role can use this key." What we will be doing is granting permission to a role instead of granting it directly to a user; users who assume that role now automatically get access to that key and the permissions inside it.

**Figure 1.2**

*Lost and Found Animal - Define key usage permissions*

After the above step, I set the block of all public access: No other user except those I have added as users or roles can view or change the content of the bucket. Since I have not permitted any outsiders, the data is kept safe from unauthorized access. This approach ensures that only those having certain roles and permissions can in any way interact with the content. This provides a heightened level of security with completely blocked public access. This is an absolute must in securing sensitive data and having control over who can view or perform alterations on the bucket.

In most of these scenarios, users can't share keys or know each other but should communicate securely. In cases like this, symmetric encryption is applied, using the very same key both for encrypting and decrypting.

- Key type: **Symmetric** means we can use one key free for both actions (both encryption and decryption). It is another technique for encryption to use one key for another encryption.

**Figure 1.3**

*Lost and Found Animal - Review - Symmetric*

In the **Properties**, I changed the default encryption settings; thus, every newly uploaded dataset into the bucket would be automatically encrypted with the given key. This means for all future uploads each file stored in the bucket will be securely encrypted. Whenever a user desires to download any dataset from this bucket, it will automatically get decrypted using the same key; hence, smoothly. While it does not change the way users upload and download data, it will store and protect data securely. This is the configuration for the encryption of sensitive information without complicating normal bucket operations.

**Figure 1.4**

` `*Lost and Found Animal - Default Encryption*

**Figure 1.5**

*Lost and Found Animal - Bucket Versioning*

Next, I enabled bucket versioning, and thus directly influenced the storage costs. If versioning had not been enabled, upon uploading a new object by users, only the latest version remained, while the older version was automatically deleted. Versioning, however, allows storing multiple versions of the same file every time a user uploads it in the bucket. While this feature provides the benefit of keeping prior versions for recovery or reference, the positive feature entails a drawback of high storage usage and hence a remarkably increasing cost with time passing and the increased number of file versions**.** 

When a user has only one bucket, and something happens to it, all of their data is lost. I created an availability backup bucket just in case the original bucket was destroyed. Using AWS, in this case, I have created a new bucket stating the following information: 

- Bucket Name: animalcontrol-lostandfoundanimal-backup-lamthithuthao
- I then set server-side encryption with AWS Key Management Service keys (SSE-KMS) for added security.
- I chose the available KMS key that was associated with the bucket and turned the bucket key on for extra efficiency in encryption management.
- I enable bucket versioning so multiple versions of the files can be saved to make sure that past versions have been saved.

**Figure 1.5**

*Lost and Found Animal - Backup Bucket*

Now, the new backup bucket was empty. If users want to see the content of this, it will be updated automatically by setting the **Replication Rule** on the **AWS**. For each time, users upload the file here, this file will be copied immediately. The purpose of this action is saving. If someone destroys this file, users still have a copy here. By doing these steps:

- I chose the original bucket: **animalcontrol-lostandfound-lamthithuthao**
- In the **Management** setting – choose **Create** **Replication Rule**:

\+ Replication rule name: **animalcontrol-lostandfoundanimal-replicationrule-thithuthao**

\+ Source bucket: Choose a rule scope: Apply to all objects in the bucket (it means all objects in this bucket will be copied automatically.)

\+ Destination: Bucket name browses from **animalcontrol-lostandfoundanimal-backup-lamthithuthao**

**+ IAM role: Choose from existing IAM roles – LabRole**

**+ AWS KMS key for encrypting destination objects: Choose from your AWS KMS keys and browse animalcontrol-lostandfoundanimal-key-lamthithuthao**

**Figure 1.6**

*Lost and Found Animal - Replication Rule*

After finishing this step, if users upload objects in the original file, these objects will be replicated and encrypted at the same time and are being implemented for free. 

## <a name="_toc1296611196"></a><a name="_toc177337079"></a>**Step 16: Data Governance***   
I have first of all created another folder named **Trusted** into the 2024 zone. Next, I created a new folder in the Trusted zone, also, which is called **Lost-And-Found-Animal**.

On the **AWS Glue**, I created a **new Virtual ETL** was created and named: **AmlCntrl-LostFdAml-DQDP-ThaoLam**

It then initiates its job by fetching the raw data from the S3 bucket named **FetchRaw-LostFdAml**

The **EvlDataQlty-LostFdAml** step checks the data for quality by its completeness using a rule created by me. It checks in this instance that the **LostFoundAnimalName** field is **Completeness,** **over 95%.** The forward computations have passed this quality check; thus, the data was not flimsy.

**Figure 1.7**



*Lost and Found Animal - Evaluate Data Quality![](Aspose.Words.4d1f7fc7-66eb-4c88-89bf-3870057df665.002.png)*

**Figure 1.8**

*Lost and Found Animal - rowLevelOutcomes* 

The box **rowLevelOutcomes** selects rows depending on the result of the data quality assessment. It added new columns to indicate data quality errors.

The **Conditional Router** node routes the data into two various output groups:

- **PassedGroup**: Group for all records that meet the condition, where **DataQualityEvaluationResult** is marked as "**Passed**." The filter condition is set to an exact match.
- **default\_group**: The records in this group **failed** to meet any of the supplied selectors and may have been forwarded to a fallback endpoint for processing or other disposition.

The target is set to load the transformed data into an S3 bucket named **AmzS3-LDAml-Trusted**, without compression, in **CSV** format. I choose not to update the data catalogue during this step.

**Figure 1.9**

*Lost and Found Animal - Conditional Router*

**Figure 1.10**

*Lost and Found Animal - Visual ETL*



![](Aspose.Words.4d1f7fc7-66eb-4c88-89bf-3870057df665.003.png) 	

After Save and Run the Visual ETL, the processed data from the job AWS Glue has been successfully stored in the Trusted folder that I created in the first step. Ensuring the data is available for further use or analysis.

In step 16, I will answer the questions: "How to guarantee data quality?" and "How to guarantee data privacy?". 

- It ensures data quality through automation checks such as completeness and schema validation, and routes data conditionally based on an evaluation's outcome, ensuring that only high-quality data ever enters the processing system. The job also uses a structured approach to filter and handle data based on quality criteria. 
- Besides, the job ensures data privacy by finding sensitive information, encrypting at rest and transit, and controlling access via permission settings and AWS KMS keys. These security measures allow private data to be protected, accessible only to users who have been allowed to see it, and in compliance with the set bases of privacy.

## <a name="_toc1188048118"></a><a name="_toc177337080"></a>**Step 17: Data Monitoring**
Below is the **CloudWatch** dashboard that was applied to track the two key metrics: **EstimatedCharges** and **NumberOfObjects.** The EstimatedCharges metric plots a time series of charges accrued in this project, while the NumberOfObjects metric tracks the number of objects in S3 over the last week. This helps in monitoring both cost and storage usage for the project.

**Figure 1.11**

*Lost and Found Animals - CloudWatch Dashboard – 2 Line Charts*

Next, I worked with AWS CloudWatch to create and configure an **Alarm** to track the project's estimated charges and resource usage. I created an alarm that would trigger when the EstimatedCharges is equal to or greater than $50 within a time window of 6 hours continuously.

**Figure 1.12**

*Lost and Found Animals - Alarm - Setting Condition*

Then, I have configured **Alarm Notifications**. I have chosen the pre-existing SNS topic 'Default\_CloudWatch\_Alarms\_Topic'. In addition, I have added an email notification for my email: ***(thithuthao.lam@myucwest.ca).*** By so doing, an email will be sent out in case charges exceed the $50 limit.

**Figure 1.13**

*Lost and Found Animals - Alarm – Setting Notification*



Specifically, using Alarms allows tracking in real-time cost-related metrics and, in turn, timely notification in case the estimated AWS charges exceed the set threshold to take immediate action for managing the project budget.

**Figure 1.14**

*Lost and Found Animals – Alarms*








**Figure 1.14**

*Lost and Found Animals - Dashboards*


Moving to **CloudTrail**, I used it to create a new trail, by setting this information:

- Name: **animalcontrol-lostfoundanimal-Trail-thithuthao**
- I changed the Trail log bucket and folder to: **aws-cloudtrail-logs-animalcontrol-lostfoundanimal-users**
- I set the AWS KMS alias, named: **animalcontrol-lostfoundanimal-logkey-thithuthao**
- Event type: Management events

**Figure 1.15**

*Lost and Found Animals - Setting Trail*

` 	`The configuration allows the continuous monitoring of all actions and changes regarding AWS resources that are part of a project to be done transparently and securely. At the same time, I enabled SSE-KMS encryption. In this case, it uses a custom-managed AWS Key Management Service to protect the log files, thus allowing secure access to the logs. This is important for compliance and security reasons since unauthorized access is blocked to normally sensitive log data.

**Figure 1.16**

*Lost and Found Animals - CloudTrail*




**Figure 1.17**

*Lost and Found Animals – CloudTrail Folders*

All the above actions performed represent setting up monitoring with CloudWatch and audit logging with CloudTrail. These allow tracking all activities and access within the AWS account with CloudTrail, and CloudWatch allows tracking usage, performance, and billing metrics. Together, they help to be sure of data security and cost management within the project.

**Figure 1.18**

*Lost and Found Animals - CloudWatch and CloudTrail*



**Dataset 2: 3-1-1 Service Requests Regarding “Abandoned Non-Recyclables—Small Case” (By Ugochukwu Nwosu)**
# <a name="_toc175690284"></a><a name="_toc177337081"></a>**DAP Design and Implementation (Step 15-17)**
## <a name="_toc177337082"></a>**Step 15: Data Protection**
`	`This step ensures that the data processed, stored, and transmitted in your AWS Data Analytic Platform (DAP) is secure from attacks such as theft, loss, and breaches. Security is an essential subprocess incorporated in the DAP to protect information, particularly when managing the City of Vancouver waste management data.

`	`As illustrated in the screenshots below, the security measures included IAM policies, encryption and data protection monitoring. IAM was set to comply with the principle of least privilege, which meant that only those users and roles that had permission to access sensitive objects, such as S3 buckets, were allowed to do so, and all were set to enforce MFA. To address the protection of data at rest, the Server-Side Encryption (SSE) and AWS Key Management Service (KMS) were applied for server-encrypted S3 with AWS-managed keys and customer-managed keys, respectively, to protect the data and protect them from access by third parties. Furthermore, S3 buckets were set up with cross-region replication, which offered backups and safeguard mechanisms in case of regional blackouts. Lastly, Amazon CloudTrail was implemented to record all activities carried out in the AWS account, who exactly completed the activity, and changes made to resources, thus providing a clear record of the shadow behind activities performed and making it easier to identify security threats. This comprehensive data protection guarantees its safety when it is collected, stored, processed, transmitted, and even aggregated with other datasets.

**Figure 2.1**

*IAM Role setup showing permissions to access S3.*


**Figure 2.2**

*S3 bucket with encryption enabled (SSE-S3 or SSE-KMS).*


**Figure 2.3**

*CloudTrail monitoring setup for access auditing and security monitoring.*


**Figure 2.4**

*S3 Bucket Replication for Back up.*


## ` `**<a name="_toc177337083"></a>Step 16: Data Governance**
**	Data governance ensures that data within the Data Analytical Platform (DAP) is managed according to best practices and regulatory standards. It focuses on maintaining data quality, ensuring compliance, and setting up data access, management, and usage policies. In using data governance while adapting it to be used on the City of Vancouver’s Data Analytic Platform, the use of AWS Glue and AWS Lake Formation provided a solid foundation to manage the data assets and its controls for access. AWS Glue was used to store all datasets, and crawlers automatically crawled through the data in S3 to classify datasets and provide unified metadata. This catalog also helps in the discovery and organization of data. Then, AWS Lake Formation was used to manage access, meaning different users had different permissions to access the data lake.

Furthermore, IAM policies were extended to Lake Formation to enhance the policy controls and allow access only to the required data. AWS CloudWatch was configured to log all data access operations for added auditability. This form of governance ensures that available data in the platform should only be accessed, managed, and reviewed by the appropriate staff and properly for compliance purposes.

**Figure 2.5**

*AWS Glue Data Catalog: After Running the Crawler.*


**Figure 2.6**

*Data Lake Permissions*


**Figure 2.7**

*CloudWatch Log Events*


## ` `**<a name="_toc177337084"></a>Step 17: Data Monitoring**
This step ensures that data processes within the City of Vancouver's AWS Data Analytic Platform (DAP) are continuously monitored for performance, security, and operational efficiency.

**Figure 2.8**

*CloudTrail and CloudWatch Activity Monitoring*


**Figure 2.9**


**Dataset 3: Business Licences in Downtown Vancouver (By Gurleen Kaur Khosa)**
# <a name="_toc175690298"></a><a name="_toc177337085"></a>**DAP Design and Implementation (Steps 15- 17)**
## <a name="_toc177337086"></a>**Step 15: Data Protection**
To ensure data protection, I implemented the following steps using AWS Key Management Service (KMS).

***Create a Key***

- Designed layout in draw.io.
- Created a key for my domain: business-businesslicence-key-gurleen using KMS.
- Defined key administrative permissions, assigning the LabRole to manage the key.
- Granted permissions for key usage, allowing users with the LabRole to use the key for encryption.

***Block Public Access***

Blocked all public access to the bucket, ensuring only authorized users with specific roles and permissions can interact with the content.

**Figure 3.1**

*Business-BusinessLicence-Gurleen - KMS Design*


**Figure 3.2**

*Business-BusinessLicence-Gurleen - Configuring KMS*


**Figure 3.3**

*Business-BusinessLicence-Gurleen - Key Usage Permissions*


**Figure 3.4**

*Business-BusinessLicence-Gurleen - Key Administrative Permissions*


**Figure 3.5**

*Business-BusinessLicence-Gurleen - Reviewing Ker Configuration Steps*


**Figure 3.6**

*Business-BusinessLicence-Gurleen - Created Key Result*


***Configure Encryption***

- Changed default encryption settings to use the created key for automatic encryption of newly uploaded datasets.
- Enabled bucket versioning, allowing multiple versions of files to be stored for recovery or reference.

**Figure 3.7**

*Business-BusinessLicence-Gurleen - Bucket Versioning*


***Create a Backup Bucket***

- Created a backup bucket: business-businesslicence-backup-gurleen
- Set server-side encryption with AWS KMS keys (SSE-KMS) for added security.
- Enabled bucket versioning to store multiple versions of files.

**Figure 3.8**

*Business-BusinessLicence-Gurleen - Backup Bucket*


***Set up Replication Rule***

- Created a replication rule to automatically copy files from the original bucket to the backup bucket.
- Chose the original bucket, source bucket, and destination bucket.
- Selected the LabRole IAM role and the created KMS key for encrypting destination objects.

**Figure 3.9**

*Business-BusinessLicence-Gurleen - Replication Rule*


By following these steps, I ensured that data is protected with symmetric encryption, and multiple versions of files are stored for recovery or reference. The backup bucket provides an additional layer of security in case the original bucket is destroyed.
## <a name="_toc177337087"></a>**Step 16: Data Governance**
In this step, to ensure data quality and privacy, I created a data governance process using AWS Glue. I set up a Virtual ETL job, **Business-BusinessLicence-DQDP-Gurleen**, which fetches raw data from an S3 bucket. The job checks the data for quality using a rule that ensures the **LicenseStatus** column is complete over 95%. The data is then routed based on the quality assessment, with high-quality data passing through to the next step using conditional router node which divides data into two categories – one being **PassedGroup** which contains all the records that exactly match with the filter condition and **DataQualityEvaluationResult** is marked as Passed. Another category of conditional router is default\_group which contains records which failed the **DataQualityEvaluationResult**.

The job also ensures data privacy by detecting sensitive information, encrypting data at rest and in transit, and controlling access through permission settings and AWS KMS keys. This ensures that private data is protected and only accessible to authorized users, in compliance with privacy regulations.

The processed data is stored in an S3 bucket, business-businesslicence-trusted, in CSV format, without compression. This ensures that the data is available for further use or analysis. Finally, we run the job.

**Figure 3.10**

*Business-BusinessLicence-Gurleen - ETL Pipeline Implementation for DQDP*


**Figure 3.11**

*Business-BusinessLicence-Gurleen - ETL Pipeline Implementation for DQDP*


**Figure 3.12**

*Business-BusinessLicence-Gurleen - Full overview of ETL Pipeline Implementation for DQDP*


**Figure 3.13**

*Business-BusinessLicence-Gurleen - Job run for ETL Pipeline*


**Figure 3.14**

*Business-BusinessLicence-Gurleen - ETL Pipeline Implementation Result*


## <a name="_toc177337088"></a>**Step 17: Data Monitoring**
***Monitoring and Auditing with CloudWatch and CloudTrail*** 

To ensure data security and cost management, I set up monitoring with CloudWatch and audit logging with CloudTrail.

Firstly, designed it in draw.io.

**Figure 3.15**

*Business-BusinessLicence-Gurleen - Cloud Watch design in draw.io*


***Monitoring Cost and Storage Usage with CloudWatch***

To monitor the project's cost and storage usage, I created a dashboard that keep in check two metrics: EstimatedCharges and NumberOfObjects. The EstimatedCharges metric ensures time series of charges utilized in the project whereas NumberOfObjects used for specific service say Amazon S3 metric tracks the number of objects used in S3 over the last month. This setup enables me to monitor both cost and storage usage for my project.

**Figure 3.16**

*Business-BusinessLicence-Gurleen - Creating Dashboard*


**Figure 3.17**

*Business-BusinessLicence-Gurleen - Dashboard creation result*


**Figure 3.18**

*Business-BusinessLicence-Gurleen - Metric and conditions specified*


**Figure 3.19**

*Business-BusinessLicence-Gurleen - Metrics for estimated charges and No.of objects*


**Figure 3.20**

*Business-BusinessLicence-Gurleen - Resource Usage Metrics*


***Configuring Alarms for Cost Management***

I created an alarm in CloudWatch to track the project's estimated charges and resource usage. The alarm is set to trigger within a time frame of 6 hours, when the EstimatedCharges is equal to or greater than $35. If this number is greater than specified threshold, then we will be notified about this via email so that we can take timely action if required to manage the budget of the project.

***Configuring Alarm Notifications***

I configured alarm notifications and added my email address to get email notifications if my cost usage exceeds $35.

**Figure 3.21**

*Business-BusinessLicence-Gurleen - Configuring alarms*


**Figure 3.22**

*Business-BusinessLicence-Gurleen - Alarm creation result*


***Monitoring AWS Resources with CloudTrail***

I created a new trail in CloudTrail named business-businesslicence-trail-gurleen, setting up a log bucket and folder, an AWS KMS alias, and enabling SSE-KMS encryption. This allows for continuous monitoring of all actions and changes regarding AWS resources, ensuring transparent and secure access to logs blocking unauthorized access to sensitive log data.

***Benefits of Monitoring and Audit Logging***

By setting up monitoring with CloudWatch and audit logging with CloudTrail, I can track all activities and access within the AWS account. CloudWatch allows tracking usage, performance, and billing metrics, while CloudTrail provides a record of all actions and changes regarding AWS resources. Data security and cost management within the project can be ensured using these AWS services.

**Figure 3.23**

*Business-BusinessLicence-Gurleen - Creating Trail*


**Figure 3.24**

*Business-BusinessLicence-Gurleen - Trail creation result*


**Figure 3.25**

*Business-BusinessLicence-Gurleen - Cloud trail logs*


**Figure 3.26**

*Business-BusinessLicence-Gurleen - Trail final output*


**Dataset 4: Rental Standards (By Jaykishan Ashokkumar Patel)**
# <a name="_toc175690326"></a><a name="_toc177337089"></a>**DAP Design and Implementation (Steps 15- 17)**
## <a name="_toc177337090"></a>**Step 15: Data Protection**
Identity and Access Management (IAM) on AWS is used for data protection to control Access. IAM enables you to create policies as to which user/service is allowed to have access to what resource such as S3 buckets or EC2 instances hence limiting the access of sensitive data to unauthorized persons. As you know, the principle of least privilege represents the approach in which only the necessary permissions are assigned to user or role and thus minimizing the threat to the data.

**Figure 4.1**

*Data Protection*


## <a name="_toc177337091"></a>**Step 16: Data Governance**
AWS Glue is specifically helpful in data governance as it comes with features that help in extracting, transforming and loading of data from different sources. Its features automate compliance, data security, and data standard in data lakes and every other AWS ecosystem. In other words, AWS Glue Data Catalog is used as a central location for dataset information. It intelligently crawls data from different sources including Amazon S3, RDS, Redshift and other related sources and stores the data with related information such features as schema, format and location.

**Figure 4.2**

*Data Governance*


## <a name="_toc177337092"></a>**Step 17: Data Monitoring**
Data monitoring is achieved through features in DataBrew that are intended for data profiling, validation and transformation in order to detect and correct anomalies in the data preparation process. As a tool, it allows for the quantification and pre-processing of data, which should be clean before data analytics or even before the implementation of machine learning.

**Figure 4.3**

*Data Monitoring*


# <a name="_toc1341343242"></a><a name="_heading=h.fqbcnhadkg4z"></a><a name="_toc177337093"></a>**DAP Architecture Analysis (Teamwork)**
The City of Vancouver's architectural framework, which utilizes the Data Analytics Platform, is profoundly assessed and conforms to the AWS Well-Architected Framework. This assessment guarantees that the platform achieves key performance, security, reliability, cost efficiency, and sustainability indicators according to best practices and standards.
## <a name="_toc177337094"></a>**1. Operational Excellence**
When it comes to AWS Cloud and DAP architecture, operational excellence is the ability to execute workloads efficiently, obtain insights into the workflows, and improve work execution over time. First, the operational excellence of AWS Well-Architected Framework offers the best practices that must be implemented in any DAP architecture.

***Evaluation Areas for Operational Excellence***

- **Monitoring and Logging:** CloudWatch helps monitor data pipelines and operational issues. Logs from all components of the DAP are aggregated into a central logging solution, such as AWS CloudTrail or third-party logging tools. This assist in supervising the access and operation events that occur in the architecture.
- **Automation and Consistency:** Automation is being applied for infrastructural management. Some of the tools that can be harnessed in deploying consistent environments are AWS CloudFormation or even Terraform. Other services like Amazon EC2 Auto Scaling, AWS Lambda or AWS Fargate which were used to automatically scale the system dynamically depending on the traffic intensity. Auto-scaling works to improve operation excellence in that it adapts to traffic and load.
- **Change Management and Continuous Improvement:** The DAP employs actionable codebase in developing the infrastructure where version control is employed. Version control should be done using AWS CodeCommit or Git and other such tools. CI/CD is also integrated there, and it is stated that there are automations when it comes to deployments and testing. GitHub Auto-merge and AWS CodeDeployment should help prevent issues like pipeline failures to avoid problems such as those faced with AWS CodePipeline or Jenkins.
## <a name="_toc177337095"></a>**2. Security**
Security is strongly emphasized in AWS data access point DAP architecture because data, systems, and workloads require protection. AWS proposes a model of shared responsibility in which Amazon is responsible for security at the cloud level and the users responsible for security in the cloud. 

***Evaluation Areas for Security***

1. **Identity and Access Management (IAM)**
   1. ***Access Control***: Make certain that only those users or services that require data and components within the DAP should be allowed to access such.
   1. ***Multi-Factor Authentication (MFA)***: AWS IAM MFA places another form of security blanket.
1. **Encryption**
   1. ***Data Encryption at Rest***: AWS KMS should be used for encrypting and managing keys because of its capacity of highly secure storage of encryption keys. Data Encryption in Transit: TLS (Transport Layer Security) should actually be used in providing security to data in transit from clients to the services.
1. **Security Auditing and Compliance**
   1. ***Auditing with AWS CloudTrail***: This makes it possible for you to track in your audits, who accessed what, at any given time. AWS Config: Is the AWS Config and AWS Config Rules used to perform the continuous evaluation of resource configurations against the best practices for information security and compliance?
## <a name="_toc177337096"></a>**3. Reliability**
<a name="_heading=h.ymso366pwqly"></a>The reliability of the AWS DAP platform of the City of Vancouver involves a major concentration on different aspects. Evaluation of the Reliability of DAP based on the AWS Well-Architected Framework will involve several aspects such as workload architecture, change management, and failure management.

***Key Reliability Design Principles Applied in DAP***

1. **Automatically Recover from Failure:** In the DAP for the City of Vancouver, there are specific features that enhance the capacity to recover from failure. AWS CloudTrail and CloudWatch logging and monitoring have been put in place to baseline all activities and changes continuously in the AWS resources involved. These provide real-time insight, with automation responses to thresholds and anomalies, to enable the platform to bounce back swiftly and efficiently in the event of an interruption.
1. **Test Recovery Procedures:** The project gives various recovery procedures through constant monitoring and testing that goes on across different environments. These recovery processes further validate the reliability of some of the key parts of the system, which include AWS Glue, EC2, and S3. Testing on these components ensures that points that can be potential failures are flagged off and thereby not allowed to make disturbances to the platform.
1. **Scale Horizontally to Increase Aggregate Availability:** The server can horizontally scale with large volumes of data and traffic by using Amazon S3 for scalable data storage and leveraging EC2 to publish the web application. The design enhances the system's availability since it spreads resources and workload over many instances.
1. **Stop Guessing Capacity:** The system utilizes Amazon CloudWatch, a real-time resource usage monitoring tool that exhibits visibility crucial for scaling resources based on demand. This secret ensures that the platform operates efficiently without overloading a single component or running into capacity constraints. 
1. **Manage Change in Automation:** The DAP enjoys automation for ETL processes using AWS Glue and SQL querying on data residing in S3 using AWS Athena. This automation of the system reduces manual intervention to a minimum, hence jumping to changes faster with minimal errors.
1. **Resilience and Fault Tolerance Encryption** for the logs is secured by AWS KMS, while AWS EC2 ensures that the web servers are up and running; thus, there is durability in cases of security breaches or data corruption. Logs can be safely stored within AWS S3 buckets with enabled encryption of them, hence enhancing integrity and compliance.

In a nutshell, the Reliability of DAP is ensured by the application of principles afforded by the reliability pillar of AWS’s Well-architected Framework. With automatic recovery mechanisms, real-time monitoring, and secure data managing practices, DAP is highly reliable to function efficiently, fail quickly, and recover.
## <a name="_toc177337097"></a>**4. Performance Efficiency**
We can consider the following analysis based on the Performance Efficiency Pillar of the AWS Well-Architected Framework to assess the performance efficiency of the DAP project:

1. **Compute Resources**: The project leverages AWS EC2 Instances, and cloud virtual servers to publish data, featuring resizable compute capacity. That means that one would need to choose an instance type, say t2.micro, for those instance types, which offer the most cost-efficient and optimal solution during content delivery. It will scale up or down as required by workload demand. Doing so would keep things flexible by scaling or minimizing based on the jittery traffic loads received without over-provisioning of resources.
1. **Storage Resources**: Amazon S3 is a basic storage resource that provides durable and scalable storage. S3 will host large-size datasets required for the data needs of the platform. This hence ensures that any increase in the volume of data, for instance, will have S3 scaling automatically. The data is also structured and cleaned using AWS Glue to high efficiency during processing and access.
1. **Data Processing Efficiency**: AWS Glue is used, which automates ETL by extracting, transforming, and loading data. Glue will clean and prepare the data with minimum human interaction, which reduces the processing time and resources. The analytics for the data are performed via Amazon Athena, a serverless service that makes it easy to query data in S3 without managing the underlying infrastructure, hence adding efficiency.
1. **Monitoring and Scaling**: Amazon CloudWatch will be set up to track resource utilization and performance, enabling real-time metrics that will provide automatic scaling triggers. The monitoring ensures that the system can scale horizontally, changing resources according to current demand, thus avoiding performance bottlenecks and optimizing costs.
1. **Data Visualization**: for the project DAP mainly deals with developing insights from raw data into interpretable formats stakeholders can make use of. For this project, data stored in S3 had been queried through Amazon Athena, while the necessary infrastructure hosting these visualizations was provided by Amazon EC2. These utilities enable the making of better decisions through the representation of complex data in a neatly digestible form: visualize-through dashboards and reports the team can track against to maintain service performance and patterns in a visually appealing fashion.

In a nutshell, the DAP project follows best practices, ensuring that architectures are performant even at scale they use scalable storage (Amazon S3), efficient data processing (AWS Glue and Athena), optimized computing (EC2), and real-time monitoring (CloudWatch).
## <a name="_toc177337098"></a>**5. Cost Optimization**
<a name="_heading=h.x3zz8tyo6lq9"></a><a name="_heading=h.aq9cphvmv0yq"></a>AWS cost optimization is done using various AWS services where required. S3 Intelligent Tiering is smart as it moves seldom-accessed data to the more affordable storage tiers while ensuring that such data is accessible without incurring expenses (AWS, 2024). This inexpensive approach extends to using AWS Cost Explorer, where one can assess real-time usage, and the amount spent on resources (AWS Cost Explorer, 2024). Checking the effectiveness of the work with the help of these indicators is possible through their periodic analysis. Therefore, the team can find and exclude waste, which must be a priority when working on the platform, to achieve the set goal and, at the same time, save money. Still, utilizing other application-layer services, such as AWS SNS and AWS Cognito, will contribute to cost savings even more. Subsequent initiatives should center on procuring additional managed services and fine-tuning cost optimization strategies as the spread of the platform widens.
## <a name="_toc177337099"></a>**6. Sustainability**
<a name="_heading=h.ua2kjmmtbl7g"></a>Finally, sustainability is integrated into the DAP through serverless architectures and auto-scaling, which only utilizes computing resources in a way that is required to reduce energy costs and consumption. AWS Lambda and all other services under the AWS business implement the notion of reserved compute capacity only for running applications, thereby minimizing wasted time and energy. It also manages to achieve efficiency by doing away with surplus resource consumption while adapting to changes in flow, thereby having a negligible impact on the environment. The lack of server infrastructure in serverless architectures minimizes resource wastage through less or no use of servers. Auto-scaling means that resources are adjusted depending on the usage, which helps to avoid providing more resources than necessary and, consequently, less energy consumption. These practices help to decrease the negativity of their imprint on the environment by maintaining the conservative use of resources and the carbon emissions related to the functioning of the clouds (Amazon Web Services, 2024). However, its platform lacks fault tolerance and scalability features, which must be incorporated into further development plans. Optimizations should lie in defining what constitutes a backup instance and in preemptively adding infrastructure to sustain future growth and availability.

Thus, the Data Analytics Platform for the City of Vancouver proposes a comprehensive solution to meet performance, security, reliability, cost optimization, and sustainability challenges. Using the AWS Well-Architected Framework, the platform is created to efficiently satisfy present tasks and yet be ready to embrace future demands.


# <a name="_heading=h.u5x4b6poeahz"></a><a name="_toc177337100"></a>**References**
Amazon Athena. (2024). Amazon Athena. Retrieved from <https://aws.amazon.com/athena/>

Amazon Web Services. (2024). *Using server-side encryption with Amazon S3 managed keys (SSE-S3) - Amazon simple storage service.* <https://docs.aws.amazon.com/AmazonS3/latest/userguide/UsingServerSideEncryption.html>

AWS CloudTrail. (2024). *What is AWS CloudTrail?.* Retrieved from <https://aws.amazon.com/cloudtrail/>

AWS Cost Explorer. (2024). *AWS Cost Explorer*. Retrieved from <https://aws.amazon.com/aws-cost-management/aws-cost-explorer/>

AWS. (2022). *Replicate Data within and between AWS Regions Using Amazon S3 Replication*. Retrieved from <https://aws.amazon.com/getting-started/hands-on/replicate-data-using-amazon-s3-replication/>

AWS. (2024). *Amazon S3 intelligent-tiering storage class | AWS*. Amazon Web Services, Inc. <https://aws.amazon.com/s3/storage-classes/intelligent-tiering/#:~>

*Home — City of Vancouver Open Data Portal*. <https://opendata.vancouver.ca/pages/home/>

*Performance Efficiency - AWS Well-Architected Framework*. 2 July 2020, <https://wa.aws.amazon.com/wellarchitected/2020-07-02T19-33-23/wat.pillar.performance.en.html>

*Reliability - AWS Well-Architected Framework*. 2 July 2020, <https://wa.aws.amazon.com/wellarchitected/2020-07-02T19-33-23/wat.pillar.reliability.en.html>

Website Design Company in Bangalore | SEO Agency. (2024, May 30). *AWS cross-region data replication.* Website Design Company in Bangalore | Website Designers in Bangalore | Web Development Company in Bangalore | EchoPx. [https://echopx.com/aws-cross-region-data-replication/#](https://echopx.com/aws-cross-region-data-replication/)
